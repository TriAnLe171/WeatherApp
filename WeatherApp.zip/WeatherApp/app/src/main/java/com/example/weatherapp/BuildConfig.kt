package com.example.weatherapp

object BuildConfig {
    const val WEATHER_API_KEY = "6b75d9c0a75ebcb0c96c0cd5db8f0786"
}
